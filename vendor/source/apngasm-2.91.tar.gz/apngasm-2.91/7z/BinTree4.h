#ifndef __BINTREE4__H
#define __BINTREE4__H

#undef BT_CLSID
#define BT_CLSID CLSID_CMatchFinderBT4

#undef BT_NAMESPACE
#define BT_NAMESPACE NBT4

#define HASH_ARRAY_2
#define HASH_ARRAY_3

#include "BinTreeMF.h"

#undef HASH_ARRAY_2
#undef HASH_ARRAY_3

#endif

