#ifndef __BINTREE2MAIN__H
#define __BINTREE2MAIN__H

#undef BT_CLSID
#define BT_CLSID CLSID_CMatchFinderBT2

#undef BT_NAMESPACE
#define BT_NAMESPACE NBT2

#include "BinTreeMFMain.h"

#endif

