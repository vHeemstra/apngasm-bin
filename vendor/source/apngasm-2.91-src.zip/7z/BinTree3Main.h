#ifndef __BINTREE3MAIN__H
#define __BINTREE3MAIN__H

#undef BT_CLSID
#define BT_CLSID CLSID_CMatchFinderBT3

#undef BT_NAMESPACE
#define BT_NAMESPACE NBT3

#define HASH_ARRAY_2

#include "BinTreeMFMain.h"

#undef HASH_ARRAY_2

#endif

